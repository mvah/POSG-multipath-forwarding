package interfaces;

public interface IElement {
    public String getValue();
    public Integer getTaille();
}
